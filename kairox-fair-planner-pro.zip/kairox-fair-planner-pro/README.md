# KAIROX Fair Planner Pro

Sistema de planificación anual de ferias comerciales para KAIROX.

## Funciones
- Timeline horizontal anual tipo Excel/Gantt
- Montaje / Feria / Desmontaje
- Gestión de clientes por feria
- Contactos técnicos editables
- Preparado para automatización IA y scraping
- Compatible con GitHub + Vercel + Railway

## Stack recomendado
Frontend:
- Next.js
- React
- Tailwind

Backend:
- FastAPI
- PostgreSQL

## Instalación

Frontend:
```bash
npm install
npm run dev
```

Backend:
```bash
pip install -r requirements.txt
uvicorn main:app --reload
```
